"""
train_model.py
----------------
JOB: Train a Decision Tree Classifier that learns:
     "given wifi_signal, router_ping, external_ping -> what's the fault?"

Since we don't have days of real fault data yet, this file GENERATES
realistic labeled training examples for 4 situations:
   - Normal        (everything healthy)
   - WiFi fault     (weak signal, but router/internet fine once it reaches them)
   - Router fault   (router itself is slow/struggling)
   - ISP fault      (router is fine, but the internet beyond it is slow)

This is simple synthetic data generation -> good enough to demo and explain.
Later you can replace this with real logged data once you've collected enough.
"""

import random
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib


def generate_sample(label):
    """Create one row of realistic (wifi_signal, router_ping, external_ping) for a given label."""
    if label == "Normal":
        return [random.randint(70, 100), random.uniform(1, 20), random.uniform(10, 40)]

    if label == "WiFi":
        # weak signal causes both pings to look bad too (signal is the root cause)
        return [random.randint(10, 40), random.uniform(50, 150), random.uniform(60, 200)]

    if label == "Router":
        # signal is fine, but router itself replies slowly
        return [random.randint(70, 100), random.uniform(100, 300), random.uniform(100, 300)]

    if label == "ISP":
        # signal fine, router replies fast, but internet beyond it is slow
        return [random.randint(70, 100), random.uniform(1, 20), random.uniform(150, 400)]


def build_training_data(samples_per_class=200):
    rows = []
    for label in ["Normal", "WiFi", "Router", "ISP"]:
        for _ in range(samples_per_class):
            wifi, router, external = generate_sample(label)
            rows.append({
                "wifi_signal": wifi,
                "router_ping": router,
                "external_ping": external,
                "label": label,
            })
    return pd.DataFrame(rows)


def train_and_save_model(path="model.joblib"):
    df = build_training_data()

    X = df[["wifi_signal", "router_ping", "external_ping"]]
    y = df["label"]

    model = DecisionTreeClassifier(max_depth=5, random_state=42)
    model.fit(X, y)

    joblib.dump(model, path)
    print(f"Model trained on {len(df)} samples and saved to {path}")
    return model


if __name__ == "__main__":
    train_and_save_model()
