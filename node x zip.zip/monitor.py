"""
monitor.py
----------------
JOB: The main brain of the project. Every few seconds it:
   1. Collects a reading         (collect_data.py)
   2. Predicts the verdict       (using the trained model)
   3. Logs it to a CSV           (for history + dashboard)
   4. Checks recent trend        (INNOVATION: early-warning feature)

This is the file you'll explain the most in your viva - it ties everything together.
"""

import time
import csv
import os
from datetime import datetime

import joblib
import numpy as np

from collect_data import collect_reading

LOG_FILE = "history.csv"
MODEL_FILE = "model.joblib"

# How many past readings to look at when checking for a worsening trend
TREND_WINDOW = 6


def log_reading(reading, verdict, confidence):
    """Append one row (timestamp, readings, verdict, confidence) to our history CSV."""
    file_exists = os.path.isfile(LOG_FILE)

    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["timestamp", "wifi_signal", "router_ping",
                              "external_ping", "verdict", "confidence"])
        writer.writerow([
            datetime.now().isoformat(timespec="seconds"),
            reading["wifi_signal"], reading["router_ping"], reading["external_ping"],
            verdict, round(confidence, 1),
        ])


def predict_verdict(model, reading):
    """Feed the reading into the trained model -> get verdict + confidence %."""
    import pandas as pd
    X = pd.DataFrame([reading])[["wifi_signal", "router_ping", "external_ping"]]
    verdict = model.predict(X)[0]
    probabilities = model.predict_proba(X)[0]
    confidence = max(probabilities) * 100
    return verdict, confidence


def check_early_warning(metric_name):
    """
    INNOVATION FEATURE: Predictive Early Warning.

    Looks at the last TREND_WINDOW readings of one metric (e.g. router_ping).
    If it's been *consistently climbing*, estimate how many "steps" (checks)
    until it likely crosses a rough fault threshold, and warn the user early -
    instead of waiting for the fault to fully happen.

    Simple technique: fit a straight line (slope) through recent values.
    A positive, meaningful slope = "getting worse".
    """
    if not os.path.isfile(LOG_FILE):
        return None

    import pandas as pd
    df = pd.read_csv(LOG_FILE)
    if len(df) < TREND_WINDOW:
        return None  # not enough history yet

    recent = df[metric_name].tail(TREND_WINDOW).values
    x = np.arange(len(recent))

    slope, intercept = np.polyfit(x, recent, 1)  # fit a straight line

    # A rough "fault" threshold per metric (matches the ranges used in train_model.py)
    fault_threshold = {"router_ping": 100, "external_ping": 150}.get(metric_name)
    if fault_threshold is None:
        return None

    current_value = recent[-1]

    # Only warn if: values are clearly rising AND not already past the threshold
    if slope > 5 and current_value < fault_threshold:
        steps_left = (fault_threshold - current_value) / slope
        minutes_left = round(steps_left * (CHECK_INTERVAL_SECONDS / 60), 1)
        return f"'{metric_name}' rising steadily - may hit fault level in ~{minutes_left} min"

    return None


CHECK_INTERVAL_SECONDS = 5  # how often we check (shorter for demo, e.g. real use = 60s)


def run():
    model = joblib.load(MODEL_FILE)
    print("NodeX monitor running... (Ctrl+C to stop)\n")

    while True:
        reading = collect_reading()
        verdict, confidence = predict_verdict(model, reading)
        log_reading(reading, verdict, confidence)

        print(f"[{datetime.now().strftime('%H:%M:%S')}] "
              f"Wifi={reading['wifi_signal']}%  Router={reading['router_ping']:.0f}ms  "
              f"Ext={reading['external_ping']:.0f}ms  ->  {verdict} ({confidence:.0f}% confidence)")

        for metric in ["router_ping", "external_ping"]:
            warning = check_early_warning(metric)
            if warning:
                print(f"   WARNING: {warning}")

        time.sleep(CHECK_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
